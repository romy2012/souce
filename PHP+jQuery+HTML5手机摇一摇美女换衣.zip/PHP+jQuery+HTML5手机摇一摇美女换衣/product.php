<?php
include_once("connect.php");

$id = intval($_GET['id']);
if($id==0) exit;
$query = mysql_query("select * from dress where id<>'$id'");
$total = mysql_num_rows($query);
$arr = array();
if($total==0){
	$arr['msg'] = '没有足够的衣服！';
}else{
	$arr['msg'] = 1;
	while($row=mysql_fetch_array($query)){
		$pros[] = array(
			'id' => $row['id'],
			'color' => $row['color'],
			'pic' => $row['pic']
		);
	}
	$arr['pro'] = $pros[array_rand($pros)];
}
echo json_encode($arr);
?>